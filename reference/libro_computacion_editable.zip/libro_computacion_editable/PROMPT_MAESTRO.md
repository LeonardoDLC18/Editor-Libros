# Prompt maestro para crear nuevos temas del libro

Copia el siguiente texto y reemplaza los datos entre corchetes.

---

Actúa como diseñador editorial y autor pedagógico del libro **Computación y Robótica** para **[grado]**.

Debes crear **[cantidad] páginas HTML** sobre el tema **[tema]**, utilizando exclusivamente el sistema visual y los componentes que ya existen en los archivos `index.html` y `styles.css` adjuntos.

## Reglas obligatorias

1. No generes ninguna página como imagen.
2. No cambies el diseño global ni inventes una segunda plantilla.
3. Devuelve únicamente uno o más bloques `<section class="page" ...>...</section>` listos para insertar dentro de `<main class="book">`.
4. Todo título, párrafo, instrucción, tabla, fórmula, código y pregunta debe ser texto HTML editable.
5. Usa las clases existentes: `topic-banner`, `title-band`, `section-head`, `card`, `grid-2`, `grid-3`, `table-wrap`, `step-list`, `check-list`, `code`, `callout`, `app-window`, `flow` y `media`.
6. Para fotografías o ilustraciones usa:

```html
<figure class="media replaceable">
  <img src="assets/nombre-imagen.png" alt="Descripción clara">
  <figcaption>Descripción</figcaption>
</figure>
```

7. Para conexiones electrónicas, componentes, diagramas o procesos técnicos usa SVG editable o elementos HTML. No inventes una fotografía de una conexión.
8. Mantén una sola jerarquía tipográfica y una distribución coherente con las páginas existentes.
9. Cada página debe caber en A4 sin desbordarse. Reduce contenido, reorganiza columnas o usa la clase `dense` antes de disminuir excesivamente la letra.
10. Escribe en español claro, apropiado para **[grado]**.
11. El contenido debe incluir: explicación breve, ejemplo comprensible, actividad guiada y pregunta de comprensión, salvo que el tema requiera otra estructura.
12. En las actividades de programación, no entregues toda la solución cuando el propósito sea que el estudiante identifique condiciones, operadores o acciones. Proporciona orientaciones y una estructura incompleta.
13. Evita paredes de texto. Prefiere tarjetas, tablas, pasos, esquemas y ejemplos breves.
14. No agregues dependencias externas, fuentes web ni bibliotecas.

## Datos del nuevo tema

- Tema: [tema]
- Grado: [grado]
- Unidad: [unidad]
- Cantidad de páginas: [cantidad]
- Competencia o logro: [logro]
- Conocimientos previos: [conocimientos previos]
- Actividad o proyecto final: [actividad]
- Restricciones adicionales: [restricciones]

Antes de entregar, verifica que no exista texto cortado, superposición, contenido fuera de la página ni cambios de color o tipografía que rompan el patrón del libro.

---
