# Libro editable de Computación y Robótica

Esta carpeta contiene una versión reconstruida del libro en **HTML, CSS y JavaScript**. El contenido principal ya no está “aplanado” como una imagen: títulos, párrafos, instrucciones, tablas, fórmulas, algoritmos, preguntas y rótulos son elementos editables.

## Archivos principales

- `index.html`: contiene las 21 páginas del libro.
- `styles.css`: controla todo el diseño: colores, tipografías, tamaños, páginas, tarjetas, tablas y encabezados.
- `editor.js`: activa la edición en el navegador, el reemplazo de imágenes, el guardado y la exportación.
- `assets/`: contiene fotografías e ilustraciones reemplazables.
- `vista_previa.pdf`: vista de control de las 21 páginas.
- `PROMPT_MAESTRO.md`: instrucción reutilizable para pedirle a una IA nuevos temas sin cambiar el patrón visual.
- `plantilla-pagina.html`: estructura básica para agregar una nueva página.

## Cómo editar sin programar

1. Descomprime la carpeta completa.
2. Abre `index.html` con Chrome, Edge o Firefox.
3. Pulsa **Editar contenido**.
4. Haz clic en cualquier título, párrafo, paso, celda o código y escribe la corrección.
5. Haz doble clic sobre una fotografía para reemplazarla por otra imagen de tu computadora.
6. Cambia los dos colores principales y la escala del texto desde la barra superior.
7. Pulsa **Guardar** para conservar los cambios en ese navegador.
8. Pulsa **Exportar HTML** para descargar una copia del HTML con tus cambios.
9. Pulsa **Imprimir / PDF** para producir el archivo final.

> Mantén `index.html`, `styles.css`, `editor.js` y la carpeta `assets` juntos. El archivo exportado desde el navegador también debe permanecer junto al CSS y al JavaScript.

## Cómo modificar el diseño completo

Los valores principales están al inicio de `styles.css`:

```css
:root {
  --brand: #062b5f;
  --brand-2: #005ec7;
  --accent: #00d8ee;
  --font-scale: 1;
}
```

Cambiar esos valores actualiza todas las páginas. No es necesario corregir hoja por hoja.

## Flujo recomendado para nuevos temas

1. Conserva `styles.css` como sistema visual maestro.
2. Entrega a la IA únicamente el tema, grado, propósito y cantidad de páginas.
3. Adjunta `PROMPT_MAESTRO.md` y pide que devuelva solo secciones HTML compatibles con la plantilla.
4. Pega las nuevas secciones antes de `</main>` en `index.html`.
5. Revisa el contenido en modo edición y corrige directamente.
6. Usa imágenes únicamente para fotografías o ilustraciones. Construye tablas, códigos, diagramas de flujo, conexiones y componentes técnicos con HTML o SVG para que sigan siendo corregibles.

## Regla editorial clave

**Nunca generar la página completa como una imagen.**

- Texto: HTML.
- Diseño: CSS.
- Interacción de edición: JavaScript.
- Fotografías: PNG/JPG reemplazables.
- Diagramas técnicos: SVG o HTML.
- Tablas y algoritmos: HTML real.

Con esta separación, una corrección de ortografía, un dato, una fórmula o una conexión no obliga a regenerar toda la página.
