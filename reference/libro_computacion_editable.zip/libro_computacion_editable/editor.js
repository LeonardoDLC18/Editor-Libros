(() => {
  const STORAGE_KEY = 'libro-computacion-editable-v1';
  const THEME_KEY = 'libro-computacion-theme-v1';
  const book = document.querySelector('.book');
  const editBtn = document.querySelector('#toggleEdit');
  const saveBtn = document.querySelector('#saveBook');
  const resetBtn = document.querySelector('#resetBook');
  const exportBtn = document.querySelector('#exportHtml');
  const printBtn = document.querySelector('#printBook');
  const primaryPicker = document.querySelector('#primaryColor');
  const accentPicker = document.querySelector('#accentColor');
  const fontScale = document.querySelector('#fontScale');
  const imageInput = document.querySelector('#imageInput');
  let editing = false;
  let imageTarget = null;
  const originalMarkup = book.innerHTML;

  const editableSelector = [
    '.page h1', '.page h2', '.page h3', '.page h4', '.page p',
    '.page li', '.page th', '.page td', '.page figcaption',
    '.page .topic-kicker', '.page .topic-title', '.page .title-band',
    '.page .section-head', '.page .card-title', '.page .badge',
    '.page .flow-box', '.page .operator-chip', '.page .code',
    '.page .console', '.page .cover-title', '.page .cover-subtitle'
  ].join(',');


  function decoratePages() {
    document.querySelectorAll('.page:not(.cover)').forEach((page) => {
      if (!page.querySelector('.brand-header')) {
        const unit = page.dataset.unit === '2' ? 'UNIDAD 2' : '';
        page.insertAdjacentHTML('afterbegin', `
          <header class="brand-header no-edit">
            <div class="brand-block"><span class="brand-icon">&lt;/&gt;</span><span>Computación<br>y Robótica</span></div>
            <div class="grade-block">1.º de<br>Secundaria</div>
            <div class="unit-block">${unit}</div>
          </header>`);
      }
      if (!page.querySelector('.footer-stripe')) page.insertAdjacentHTML('beforeend', '<div class="footer-stripe no-edit"></div>');
      if (!page.querySelector('.page-number')) page.insertAdjacentHTML('beforeend', '<div class="page-number no-edit" aria-label="Número de página"></div>');
    });
  }

  function setEditing(state) {
    editing = state;
    document.body.classList.toggle('editing', state);
    document.querySelectorAll(editableSelector).forEach((el) => {
      if (el.closest('.no-edit')) return;
      el.contentEditable = state ? 'true' : 'false';
      el.spellcheck = state;
    });
    editBtn.textContent = state ? 'Terminar edición' : 'Editar contenido';
    editBtn.classList.toggle('primary', state);
  }

  function applyTheme(theme) {
    if (!theme) return;
    const root = document.documentElement;
    if (theme.brand) root.style.setProperty('--brand', theme.brand);
    if (theme.brand2) root.style.setProperty('--brand-2', theme.brand2);
    if (theme.accent) root.style.setProperty('--accent', theme.accent);
    if (theme.fontScale) root.style.setProperty('--font-scale', theme.fontScale);
    primaryPicker.value = theme.brand2 || '#005ec7';
    accentPicker.value = theme.accent || '#00d8ee';
    fontScale.value = theme.fontScale || '1';
  }

  function currentTheme() {
    return {
      brand: document.documentElement.style.getPropertyValue('--brand') || '#062b5f',
      brand2: primaryPicker.value,
      accent: accentPicker.value,
      fontScale: fontScale.value
    };
  }

  function save() {
    try {
      localStorage.setItem(STORAGE_KEY, book.innerHTML);
      localStorage.setItem(THEME_KEY, JSON.stringify(currentTheme()));
      saveBtn.textContent = 'Guardado';
      setTimeout(() => saveBtn.textContent = 'Guardar', 1200);
    } catch (error) {
      alert('No fue posible guardar todo en el navegador. Usa “Exportar HTML” para conservar los cambios e imágenes.');
    }
  }

  function load() {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) book.innerHTML = saved;
    const theme = localStorage.getItem(THEME_KEY);
    if (theme) {
      try { applyTheme(JSON.parse(theme)); } catch (_) { /* ignore */ }
    }
  }

  function reset() {
    if (!confirm('¿Restaurar la versión original de esta plantilla? Se perderán los cambios guardados en este navegador.')) return;
    localStorage.removeItem(STORAGE_KEY);
    localStorage.removeItem(THEME_KEY);
    book.innerHTML = originalMarkup;
    decoratePages();
    document.documentElement.removeAttribute('style');
    primaryPicker.value = '#005ec7';
    accentPicker.value = '#00d8ee';
    fontScale.value = '1';
    setEditing(false);
  }

  function exportHtml() {
    const clone = document.documentElement.cloneNode(true);
    clone.querySelector('body').classList.remove('editing');
    clone.querySelectorAll('[contenteditable]').forEach(el => el.removeAttribute('contenteditable'));
    const serialized = '<!doctype html>\n' + clone.outerHTML;
    const blob = new Blob([serialized], { type: 'text/html;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'libro-editado.html';
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  function replaceImage(file) {
    if (!file || !imageTarget) return;
    if (!file.type.startsWith('image/')) {
      alert('Selecciona un archivo de imagen.');
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      const raw = new Image();
      raw.onload = () => {
        const max = 1600;
        const scale = Math.min(1, max / Math.max(raw.width, raw.height));
        const canvas = document.createElement('canvas');
        canvas.width = Math.max(1, Math.round(raw.width * scale));
        canvas.height = Math.max(1, Math.round(raw.height * scale));
        const ctx = canvas.getContext('2d');
        ctx.drawImage(raw, 0, 0, canvas.width, canvas.height);
        imageTarget.src = canvas.toDataURL('image/jpeg', .88);
        imageTarget.alt = file.name.replace(/\.[^.]+$/, '');
        imageTarget = null;
      };
      raw.src = reader.result;
    };
    reader.readAsDataURL(file);
  }

  editBtn.addEventListener('click', () => setEditing(!editing));
  saveBtn.addEventListener('click', save);
  resetBtn.addEventListener('click', reset);
  exportBtn.addEventListener('click', exportHtml);
  printBtn.addEventListener('click', () => window.print());

  primaryPicker.addEventListener('input', (event) => {
    document.documentElement.style.setProperty('--brand-2', event.target.value);
  });
  accentPicker.addEventListener('input', (event) => {
    document.documentElement.style.setProperty('--accent', event.target.value);
  });
  fontScale.addEventListener('input', (event) => {
    document.documentElement.style.setProperty('--font-scale', event.target.value);
  });

  document.addEventListener('dblclick', (event) => {
    if (!editing) return;
    const figure = event.target.closest('.replaceable');
    if (!figure) return;
    const img = figure.querySelector('img');
    if (!img) return;
    imageTarget = img;
    imageInput.click();
  });
  imageInput.addEventListener('change', () => {
    replaceImage(imageInput.files[0]);
    imageInput.value = '';
  });

  load();
  decoratePages();
  setEditing(false);
})();
